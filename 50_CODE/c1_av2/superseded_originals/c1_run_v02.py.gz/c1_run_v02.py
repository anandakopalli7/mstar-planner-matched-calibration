#!/usr/bin/env python3
"""C1 episode runner v02 (Claude line, c1_run_v02, 2 Nov 2026) = c1_run_v01 with the binding of D16 v09 Choice 24 and the
dataset guard of R17 M2 (written by c1_av2/tests/make_c1_run_v02.py; see that file).
C1 episode runner (Claude line, c1_run_v01, 2 Nov 2026) = k8_run_v04 plus one mode for the AV2 confirmation (C1 v04
sections 3, 5.1, 7, 11), written by c1_av2/tests/make_c1_run_v01.py. --c1-folds <c1_folds_v01 JSON> runs exactly the units of
the folds (the 375 AV2 logs; one log = one scene of the stage-B caches) with the fixed design (every arm of k8_sim_v04.ARMS,
joint arms included; delays 0 2 4; decide or loop) and fits made for those folds (fits["folds_sha256"]). With --c1-plan <frozen
plan .md> it binds the plan like --prereg (sidecar hash, FROZEN_HASHES block holding the fits, folds, sim, runner and manifests)
and stamps C1_STAMP; with --standin it runs nuScenes development scenes treated as logs, stamped STANDIN_STAMP (never evidence).
The end-of-run hash guard, shards and --resume are k8_run_v04's.
C1 usage: python -B c1_run_v01.py --caches <stage-B dirs> --fits <c1 fits> --c1-folds <folds> --c1-plan <plan.md>
       --tag <t>_<route>_<mode> --mode decide|loop --out <dir> [--workers n] [--resume]
K8 episode runner (Claude line, k8_run_v04, 2 Nov 2026) = k8_run_v02 running k8_sim_v04 (the joint arms MstarJ, MstarJx),
written by tests/make_k8_joint_v04.py (K8_V04_DIFF_NOTE_v01.md). One addition: --joint with --exploratory runs a subset of
arms (Mstar and at least one joint arm among them) in decision mode on every non-development scene, stamped
S.JOINT_RUN_STAMP; launch and run records carry "joint": true and the v04 code hashes (CODE_FILES names k8_analyse_v04
and k8_joint_fit_v01). Everything else is k8_run_v02.
Joint usage: python -B k8_run_v04.py --caches <train> <val> --fits <k8_joint_fits_<t>_v01.json> --tag <t>_decide
       --mode decide --out <dir> --exploratory --joint --arms B0 B1 B3 B4 B6 B9 Mstar MstarJ MstarJx [--workers n] [--resume]
K8 episode runner (Claude line, k8_run_v02, 1 Nov 2026) = k8_run_v01 with the R15 changes (tests/make_k8_run_v02.py;
90_DECISIONS/D14_K8_DESIGN_v04.md section 5.1):
  * runs k8_sim_v02; three run modes, exactly one of them: --dev (the 10 development scenes only; asserted), --exploratory
    (the full design on every non-development scene, hash-logged before launch; outputs stamped EXPLORATORY), --prereg (a
    frozen K8 plan, v01's path); --dry-run with --dev or --exploratory stops before any scene is read or simulated;
  * per-scene shards written by the workers (numpy, shards_<tag>/), merged in (scene, arm, delay) order; --resume.
Exploratory usage: python -B k8_run_v02.py --caches <train> <val> --fits <k7_fits_<t>_v01.json> --tag <t>_<mode>
       --mode decide|loop --out <dir> --exploratory [--workers n] [--resume] [--dry-run]
K8 episode runner (Claude line, k8_run_v01, 1 Nov 2026) = k7_run_v01 running k8_sim_v01 (tests/make_k8_run_v01.py), with the
fit-free arms S.FITFREE (Z0, B0, B0a<alpha>, B0d<delta'>), the per-decision records written to decisions_<tag>.npz and the
per-episode calibration tables to cal_<tag>.npz.
K7 episode runner (Claude line, k7_run_v01, 1 Nov 2026) = k6_run_v02 running k7_sim_v01 (tests/make_k7_run_v01.py).
K6 episode runner (Claude line, v02, 1 Nov 2026). v02 (review R09 M6): runs k6_sim_v02; under --prereg the design is
fixed (every arm in S.ARMS, delays 0 2 4 keyframes, every non-development scene of the caches, 6 workers allowed to vary
only), and the run record carries the plan, fits, simulator, runner and manifest hashes. --mode decide runs
k6_sim_v02.run_decisions (one decision per keyframe from the logged ego's state; one "episode" per scene and arm) instead
of the closed loop; under --prereg both modes are run, each with the fixed arms.
v01: runs every (scene, arm, delay) episode of one tracker setting, in parallel over scenes, and writes:
  episodes_<tag>.jsonl   one summary per episode, sorted by (scene, arm, delay);
  counts_<tag>.npz       the in-loop constraint counts: episode index, cell, n, exceed (sparse).
Development mode (--dev) runs only the 10 nuScenes-mini scenes, which are excluded from every K6 analysis. Any other scene
needs --prereg: the K6 plan's sidecar hash, its frozen file block and the binding of the run inputs are checked first.
Usage: python -B k6_run_v02.py --caches <dir...> --fits <json> --tag <t> --out <dir> [--dev | --prereg <plan.md>]
       [--arms ...] [--delays-kf 0 2 4] [--workers n] [--scenes ...]
"""
import argparse
import hashlib
import json
import os
import sys
import time
from multiprocessing import Pool

import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "k8"))
import k8_sim_v04 as S  # noqa: E402
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import c1_guard_v01 as G  # noqa: E402

DEV_SCENES = ("scene-0061", "scene-0103", "scene-0553", "scene-0655", "scene-0757", "scene-0796", "scene-0916", "scene-1077",
              "scene-1094", "scene-1100")
_G = {}
EXPLORATORY_STAMP = "EXPLORATORY: nuScenes development evidence, not a confirmation"
C1_STAMP = "C1 CONFIRMATORY: AV2 (run under the frozen C1 plan)"
STANDIN_STAMP = "C1 STAND-IN: nuScenes development scenes treated as logs; a pipeline test, not evidence"
DEV_STAMP = "DEV MODE (nuScenes-mini scenes only; excluded from K8)"
N_NONDEV = 840                       # the non-development scenes of the 850 nuScenes trainval scenes in the caches
W_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
CODE_FILES = {"sim": os.path.abspath(S.__file__), "runner": os.path.abspath(__file__),
              "k6_sim_v02": os.path.join(W_ROOT, "50_CODE", "k6", "k6_sim_v02.py"),
              "analysis": os.path.join(W_ROOT, "50_CODE", "c1_av2", "c1_analyse_v01.py"),
              "k8_analyse_v04": os.path.join(W_ROOT, "50_CODE", "k8", "k8_analyse_v04.py"),
              "fit": os.path.join(W_ROOT, "50_CODE", "c1_av2", "c1_fit_v01.py"),
              "crc_exact": os.path.join(W_ROOT, "50_CODE", "c1_av2", "c1_crc_exact_v01.py"),
              "joint_fit": os.path.join(W_ROOT, "50_CODE", "k8", "k8_joint_fit_v02.py"),
              "k6_analyse_v02": os.path.join(W_ROOT, "50_CODE", "k6", "k6_analyse_v02.py"),
              "m_lib_v04": os.path.join(W_ROOT, "50_CODE", "m", "m_lib_v04.py")}


def sha256_path(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for b in iter(lambda: f.read(1 << 20), b""):
            h.update(b)
    return h.hexdigest()


def frozen_hashes(prereg):
    side = open(prereg.replace(".md", ".sha256")).read().split()[0]
    if sha256_path(prereg) != side:
        raise SystemExit("K8 plan hash mismatch")
    txt = open(prereg, encoding="utf-8").read()
    block = txt.split("FROZEN_HASHES_BEGIN")[1].split("FROZEN_HASHES_END")[0]
    hashes = {}
    for ln in block.strip().splitlines():
        if not ln.strip() or ln.startswith(("#", "(")):
            continue
        h, p = ln.split("  ", 1)
        if sha256_path(p.strip()) != h:
            raise SystemExit("frozen file changed: " + p)
        hashes[h] = p.strip()
    assert len(hashes) > 10, "frozen block is empty"
    return side, hashes


def code_hashes(fits, caches):
    """The hashes logged before launch and asserted equal at analysis time (D14 v04 section 5.1)."""
    h = {k + "_sha256": sha256_path(p) for k, p in CODE_FILES.items()}
    h["fits_sha256"] = sha256_path(fits) if fits else None
    h["manifest_sha256"] = [sha256_path(os.path.join(c, "MANIFEST.json")) for c in caches]
    return h


def _init(fits_path):
    _G["fits"] = json.load(open(fits_path)) if fits_path else None


def _shard_path(shard_dir, scene):
    return os.path.join(shard_dir, scene + ".npz")


def _scene_job(job):
    """Runs every (arm, delay) episode of one scene and writes them to one shard (m13): the episode summaries (JSON), the counts,
    the per-decision rows and the calibration tables as numpy arrays, with a local episode index. Returns only the shard path."""
    path, scene, arms, delays, mode, shard_dir, meta = job
    sc = S.Scene(path)
    fits_all = _G["fits"]
    fold = None
    if fits_all is not None:
        fold = fits_all["fold_of_scene"][scene]
        steps = ["h0p5s", "h1s", "h1p5s", "h2s", "h2p5s", "h3s", "h3p5s", "h4s"]
        fits = [fits_all["fits"][str(fold)][h] for h in steps]
    else:
        fits = None
    t0 = time.perf_counter()
    eps_l = []
    dec = {f: [] for f in S.DEC_FIELDS}
    dec_ep, stats, trk = [], [], []
    ce, cc, cn, cx = [], [], [], []
    ke, kk, kv = [], [], []

    def add(o, c):
        li = len(eps_l)
        decs = o.pop("decisions", None)
        cal = o.pop("cal", None) or {}
        o["_local"] = li
        eps_l.append(o)
        if decs is not None and len(decs["k"]):
            for f_ in S.DEC_FIELDS:
                dec[f_].append(np.asarray(decs[f_], np.int32 if f_ in S.DEC_INT else float))
            stats.append(np.asarray(decs["stats"], np.float32).reshape(-1, S.N_ST))
            trk.append(np.asarray(decs["trk"], np.float32).reshape(-1, S.N_TRK))
            dec_ep.append(np.full(len(decs["k"]), li, np.int32))
        for cell in sorted(c):
            ce.append(li)
            cc.append(cell)
            cn.append(c[cell][0])
            cx.append(c[cell][1])
        for key in sorted(cal):
            ke.append(li)
            kk.append(key)
            kv.append(cal[key])

    for arm in arms:
        if mode == "decide":
            if arm == "LOG":
                continue
            o, c = S.run_decisions(sc, arm, fits if arm not in S.FITFREE else None)
            o["scene"], o["fold"], o["delay_kf"] = scene, fold, 0
            add(o, c)
            continue
        for d in delays:
            o, c = S.run_episode(sc, arm, fits if arm not in S.FITFREE else None, d)
            o["scene"], o["fold"] = scene, fold
            add(o, c)
    cat = lambda L, dt, shape: np.concatenate(L) if L else np.zeros(shape, dt)  # noqa: E731
    arrs = {"dec_" + f_: cat(dec[f_], np.int32 if f_ in S.DEC_INT else float, (0,)) for f_ in S.DEC_FIELDS}
    arrs.update({"dec_episode": cat(dec_ep, np.int32, (0,)), "dec_stats": cat(stats, np.float32, (0, S.N_ST)),
                 "dec_trk": cat(trk, np.float32, (0, S.N_TRK)),
                 "cnt_episode": np.array(ce, np.int32), "cnt_cell": np.array(cc, np.int32), "cnt_n": np.array(cn, np.int32),
                 "cnt_exceed": np.array(cx, np.int32), "cal_episode": np.array(ke, np.int32), "cal_key": np.array(kk, np.int32),
                 "cal_values": np.array(kv, float).reshape(-1, S.N_CAL)})
    dt = time.perf_counter() - t0
    meta = dict(meta, scene=scene, seconds=dt)
    out = _shard_path(shard_dir, scene)
    tmp = out[:-4] + ".tmp.npz"
    np.savez_compressed(tmp, meta=np.array(json.dumps(meta)), episodes=np.array(json.dumps(eps_l)), **arrs)
    os.replace(tmp, out)
    return scene, out, len(eps_l), dt


def _shard_ok(p, meta):
    """--resume: a shard is reused only if its scene, mode, arms, delays and every code, fits and cache hash equal the current run's."""
    try:
        z = np.load(p)
        m = json.loads(str(z["meta"]))
    except Exception:
        return False
    return all(m.get(k) == v for k, v in meta.items())


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--caches", nargs="+", required=True)
    ap.add_argument("--fits", default=None)
    ap.add_argument("--tag", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--dev", action="store_true")
    ap.add_argument("--exploratory", action="store_true", help="D14 v04 section 5.1: the full design on every non-development scene")
    ap.add_argument("--prereg", default=None)
    ap.add_argument("--c1-folds", default=None, help="C1: the c1_folds_v01 JSON; runs exactly its units")
    ap.add_argument("--c1-plan", default=None, help="C1: the frozen C1 plan (.md with its .sha256 sidecar)")
    ap.add_argument("--standin", action="store_true", help="C1 stand-in on nuScenes development scenes (no plan)")
    ap.add_argument("--hash-log", default=G.HASH_LOG, help="the C1 plan hash log (a rehearsal passes its own)")
    ap.add_argument("--joint", action="store_true", help="v04, with --exploratory: decision mode, a subset of arms with Mstar and a "
                                                         "joint arm, every non-development scene")
    ap.add_argument("--dry-run", action="store_true", help="print the scene list, hashes and run record; simulate nothing")
    ap.add_argument("--resume", action="store_true", help="reuse per-scene shards whose hashes match")
    ap.add_argument("--arms", nargs="+", default=list(S.ARMS))
    ap.add_argument("--delays-kf", nargs="+", type=int, default=[0, 2, 4])
    ap.add_argument("--workers", type=int, default=4)
    ap.add_argument("--scenes", nargs="*", default=None)
    ap.add_argument("--mode", choices=["loop", "decide"], default="loop")
    a = ap.parse_args()
    assert int(a.dev) + int(a.exploratory) + int(a.prereg is not None) + int(a.c1_folds is not None) == 1, \
        "exactly one of --dev, --exploratory, --prereg, --c1-folds"
    assert not (a.dry_run and a.prereg), "--dry-run is for --dev and --exploratory"
    assert a.exploratory or not a.joint, "--joint goes with --exploratory"
    t0 = time.time()
    jobs = []
    for cdir in a.caches:
        man = json.load(open(os.path.join(cdir, "MANIFEST.json")))
        for scene, info in sorted(man["scenes"].items()):
            jobs.append((os.path.join(cdir, scene + ".npz"), scene, info["sha256"]))
    assert len({j[1] for j in jobs}) == len(jobs), "a scene appears in two caches"
    hashes = code_hashes(a.fits, a.caches)
    exploratory = False
    c1_mode, c1_plan_sha, c1_folds_sha = a.c1_folds is not None, None, None
    if c1_mode:   # C1: the fixed design on exactly the units of the folds, with fits made for those folds
        assert list(a.arms) == list(S.ARMS) and list(a.delays_kf) == [0, 2, 4] and not a.scenes, \
            "C1: every arm of k8_sim_v04.ARMS, delays 0 2 4, every unit of the folds (no --scenes)"
        assert a.fits, "C1 needs the fits"
        c1_folds_sha = sha256_path(a.c1_folds)
        units = set(json.load(open(a.c1_folds))["fold_of_log"])
        assert json.load(open(a.fits)).get("folds_sha256") == c1_folds_sha, "the fits were not made for these folds"
        jobs = [j for j in jobs if j[1] in units]
        assert {j[1] for j in jobs} == units, "the caches do not hold every unit of the folds"
        mans = [json.load(open(os.path.join(c, "MANIFEST.json"))) for c in a.caches]
        dsets = [G.dataset_of_manifest(m_) for m_ in mans]
        if a.standin:   # v02 (R17 M2): a stand-in never touches AV2-derived caches
            assert a.c1_plan is None, "--standin runs without a plan"
            assert all(d_ == "nuscenes" for d_ in dsets), "--standin refuses caches that are not nuScenes: %s" % dsets
            pre = STANDIN_STAMP
        else:           # v02 (D16 v09 Choice 24): frozen plan from the hash log; provenance for everything made after the freeze
            assert a.c1_plan, "a C1 confirmatory run needs --c1-plan (the frozen C1 plan)"
            c1_plan_sha, frozen = G.frozen_plan(a.c1_plan, a.hash_log)
            for p in (a.c1_folds, os.path.abspath(S.__file__), os.path.abspath(__file__)):
                G.require_bound(frozen, p)
            fj_ = json.load(open(a.fits))
            assert fj_.get("folds_sha256") == c1_folds_sha, "the fits were not made for these folds"
            if fj_.get("route") == "transfer":   # made before the freeze: its source fit is bound by the plan
                assert fj_.get("transfer_fit_source_sha256") in frozen.values(), "the transfer fit's source is not bound by the plan"
            else:                                 # made after the freeze: checked by provenance
                prov = fj_.get("provenance") or {}
                assert prov.get("plan_sha256") == c1_plan_sha, "the fits were not made under this frozen plan"
                for k_, h_ in (fj_.get("code_sha256") or {}).items():
                    assert h_ in frozen.values(), "fit code %s is not bound by the plan" % k_
            for m_, d_ in zip(mans, dsets):
                if d_ != "nuscenes":
                    assert m_.get("stage") == "B" and (m_.get("stage_b") or {}).get("frozen_plan_sha256") == c1_plan_sha, \
                        "an AV2 cache must be stage B, built under this frozen plan"
            pre = C1_STAMP
    elif a.dev:
        if a.scenes:
            assert set(a.scenes) <= set(DEV_SCENES), "--dev runs development scenes only (R15 m12): " + ", ".join(sorted(set(a.scenes) - set(DEV_SCENES)))
            jobs = [j for j in jobs if j[1] in set(a.scenes)]
        jobs = [j for j in jobs if j[1] in DEV_SCENES]
        assert len(jobs) == len(DEV_SCENES) or a.scenes, "development scenes missing from the caches"
        assert all(j[1] in DEV_SCENES for j in jobs), "a non-development scene in a --dev run (R15 m12)"
        pre = DEV_STAMP
    elif a.exploratory:
        if a.joint:   # v04: the joint arms beside M* (and chosen comparators), decision mode, every non-development scene
            assert (a.mode == "decide" and "Mstar" in a.arms and any(x in S.JOINT_ARMS for x in a.arms) and set(a.arms) <= set(S.ARMS)
                    and len(set(a.arms)) == len(a.arms) and "LOG" not in a.arms and list(a.delays_kf) == [0, 2, 4] and not a.scenes), \
                "--exploratory --joint: decision mode, Mstar and a joint arm among known arms, delays 0 2 4, every non-development scene"
        else:
            assert list(a.arms) == list(S.ARMS) and list(a.delays_kf) == [0, 2, 4] and not a.scenes, \
                "under --exploratory the design is fixed: all arms, delays 0 2 4, every non-development scene (no --scenes)"
        assert a.fits, "--exploratory needs the fits"
        jobs = [j for j in jobs if j[1] not in DEV_SCENES]
        assert not any(j[1] in DEV_SCENES for j in jobs), "a development scene in the exploratory run"
        assert len(jobs) == N_NONDEV, "the exploratory run needs every non-development scene: %d found, %d expected" % (len(jobs), N_NONDEV)
        pre = S.JOINT_RUN_STAMP if a.joint else EXPLORATORY_STAMP
        exploratory = True
    else:
        assert list(a.arms) == list(S.ARMS) and list(a.delays_kf) == [0, 2, 4] and not a.scenes,             "under --prereg the design is fixed: all arms, delays 0 2 4, every scene"
        pre, frozen = frozen_hashes(a.prereg)
        jobs = [j for j in jobs if j[1] not in DEV_SCENES]
        need = [a.fits, os.path.abspath(S.__file__), os.path.abspath(__file__)] + [os.path.join(c, "MANIFEST.json") for c in a.caches]
        for p in need:
            assert sha256_path(p) in frozen, "run input not frozen: " + p
    scene_names = sorted(j[1] for j in jobs)
    launch = {"tag": a.tag, "mode": a.mode, "prereg": pre, "exploratory": exploratory, "joint": bool(a.joint), "dry_run": bool(a.dry_run),
              "c1": c1_mode, "standin": bool(a.standin), "c1_plan_sha256": c1_plan_sha, "c1_folds_sha256": c1_folds_sha,
              "stamp": pre,
              "arms": a.arms, "delays_kf": a.delays_kf, "scenes": len(jobs), "scene_names": scene_names,
              "dev_scenes_present": sorted(set(scene_names) & set(DEV_SCENES)), "fits": a.fits, "caches": [os.path.abspath(c) for c in a.caches],
              "hashes": hashes, "code_files": CODE_FILES, "workers": a.workers, "numpy": np.__version__,
              "launched": time.strftime("%Y-%m-%d %H:%M:%S")}
    os.makedirs(a.out, exist_ok=True)
    lr_path = os.path.join(a.out, "launch_record_%s%s.json" % (a.tag, "_DRYRUN" if a.dry_run else ""))
    json.dump(launch, open(lr_path, "w"), indent=1)
    if a.dry_run:
        print("DRY RUN (%s): %d scenes, mode %s, %d arms, delays %s" % (pre, len(scene_names), a.mode, len(a.arms), a.delays_kf))
        print("scenes: " + " ".join(scene_names))
        print("hashes: " + json.dumps(hashes, indent=1))
        print("run record (launch): " + json.dumps({k: v for k, v in launch.items() if k != "scene_names"}, indent=1))
        print("DRY RUN: no scene cache was read and no scene was simulated; launch record " + lr_path)
        return
    for p, scene, h in jobs:
        assert sha256_path(p) == h, "cache file differs from its manifest: " + p
    shard_dir = os.path.join(a.out, "shards_%s" % a.tag)
    os.makedirs(shard_dir, exist_ok=True)
    meta0 = {"tag": a.tag, "mode": a.mode, "arms": list(a.arms), "delays_kf": list(a.delays_kf), "prereg": pre,
             "sim_sha256": hashes["sim_sha256"], "runner_sha256": hashes["runner_sha256"], "fits_sha256": hashes["fits_sha256"]}
    todo, reused = [], []
    for p, scene, h in jobs:
        meta = dict(meta0, cache_sha256=h)
        if a.resume and os.path.exists(_shard_path(shard_dir, scene)) and _shard_ok(_shard_path(shard_dir, scene), dict(meta, scene=scene)):
            reused.append(scene)
            continue
        todo.append((p, scene, a.arms, a.delays_kf, a.mode, shard_dir, meta))
    times = []
    if todo:
        with Pool(a.workers, initializer=_init, initargs=(a.fits,)) as pool:
            for i, (scene, sp, n_ep, dt) in enumerate(pool.imap_unordered(_scene_job, todo, chunksize=1)):
                times.append(dt)
                if (i + 1) % 25 == 0 or i + 1 == len(todo):
                    print("scenes %d/%d  %.0f s" % (i + 1, len(todo), time.time() - t0), flush=True)
    # merge the shards in (scene, arm, delay) order: v01's layout
    arm_rank = {x: i for i, x in enumerate(a.arms)}
    eps = []
    parts = {}
    shard_times = []
    for scene in scene_names:
        z = np.load(_shard_path(shard_dir, scene))
        m = json.loads(str(z["meta"]))
        assert m["scene"] == scene and m["sim_sha256"] == hashes["sim_sha256"] and m["runner_sha256"] == hashes["runner_sha256"], \
            "shard of %s made by other code" % scene
        shard_times.append(float(m["seconds"]))
        eps_l = json.loads(str(z["episodes"]))
        order = sorted(range(len(eps_l)), key=lambda i: (arm_rank[eps_l[i]["arm"]], eps_l[i]["delay_kf"]))
        remap = np.zeros(len(eps_l), np.int64)
        for i in order:
            o = eps_l[i]
            o.pop("_local", None)
            o["episode"] = len(eps)
            o["stamp"] = pre
            remap[i] = len(eps)
            eps.append(o)
        for pre_, fields in (("dec_", ["episode"] + list(S.DEC_FIELDS) + ["stats", "trk"]), ("cnt_", ["episode", "cell", "n", "exceed"]),
                             ("cal_", ["episode", "key", "values"])):
            ep_new = remap[z[pre_ + "episode"]] if len(z[pre_ + "episode"]) else np.zeros(0, np.int64)
            perm = np.argsort(ep_new, kind="stable")
            for f_ in fields:
                v = ep_new if f_ == "episode" else z[pre_ + f_]
                parts.setdefault(pre_ + f_, []).append(v[perm])
    cat = lambda k, dt: np.concatenate(parts[k]).astype(dt) if parts.get(k) else np.zeros(0, dt)  # noqa: E731
    ep_path, ct_path = os.path.join(a.out, "episodes_%s.jsonl" % a.tag), os.path.join(a.out, "counts_%s.npz" % a.tag)
    with open(ep_path, "w") as f:
        for o in eps:
            f.write(json.dumps(o) + "\n")
    np.savez_compressed(ct_path, episode=cat("cnt_episode", np.int32), cell=cat("cnt_cell", np.int32),
                        n=cat("cnt_n", np.int32), exceed=cat("cnt_exceed", np.int32), stamp=np.array(pre))
    dc_path = os.path.join(a.out, "decisions_%s.npz" % a.tag)
    darr = {"episode": cat("dec_episode", np.int32)}
    for f_ in S.DEC_FIELDS:
        darr[f_] = cat("dec_" + f_, np.int32 if f_ in S.DEC_INT else float)
    darr["ob"] = darr["ob"].astype(np.int8)
    darr["infeasible"] = darr["infeasible"].astype(np.int8)
    darr["stats"] = np.concatenate(parts["dec_stats"]).astype(np.float32).reshape(-1, S.N_ST) if parts.get("dec_stats") else np.zeros((0, S.N_ST), np.float32)
    darr["trk"] = np.concatenate(parts["dec_trk"]).astype(np.float32).reshape(-1, S.N_TRK) if parts.get("dec_trk") else np.zeros((0, S.N_TRK), np.float32)
    np.savez_compressed(dc_path, st_fields=np.array(S.ST_FIELDS), trk_fields=np.array(S.TRK_FIELDS), stamp=np.array(pre), **darr)
    cl_path = os.path.join(a.out, "cal_%s.npz" % a.tag)
    np.savez_compressed(cl_path, episode=cat("cal_episode", np.int32), key=cat("cal_key", np.int32),
                        values=(np.concatenate(parts["cal_values"]) if parts.get("cal_values") else np.zeros((0, S.N_CAL))).reshape(-1, S.N_CAL),
                        fields=np.array(S.CAL_FIELDS), stamp=np.array(pre))
    hashes_end = code_hashes(a.fits, a.caches)
    assert hashes_end == hashes, "code, fits or manifests changed during the run"
    rec = {"tag": a.tag, "mode": a.mode, "prereg": pre, "exploratory": exploratory, "joint": bool(a.joint), "dry_run": False, "stamp": pre,
           "c1": c1_mode, "standin": bool(a.standin), "c1_plan_sha256": c1_plan_sha, "c1_folds_sha256": c1_folds_sha,
           "arms": a.arms,
           "delays_kf": a.delays_kf, "scenes": len(scene_names), "episodes": len(eps),
           "fits": a.fits, "fits_sha256": hashes["fits_sha256"], "sim_sha256": hashes["sim_sha256"],
           "runner_sha256": hashes["runner_sha256"], "manifest_sha256": hashes["manifest_sha256"], "hashes": hashes,
           "launch_record": os.path.abspath(lr_path), "launch_record_sha256": sha256_path(lr_path), "hashes_equal_at_end": True,
           "caches": [os.path.abspath(c) for c in a.caches], "episodes_sha256": sha256_path(ep_path), "counts_sha256": sha256_path(ct_path),
           "decisions_sha256": sha256_path(dc_path), "decisions": int(len(darr["k"])), "cal_sha256": sha256_path(cl_path),
           "scene_names": scene_names, "shards_reused": len(reused), "numpy": np.__version__, "seconds": round(time.time() - t0, 1),
           "scene_seconds_median": float(np.median(shard_times)) if shard_times else None,
           "scene_seconds_sum": float(np.sum(shard_times)) if shard_times else None}
    json.dump(rec, open(os.path.join(a.out, "run_record_%s.json" % a.tag), "w"), indent=1)
    print(json.dumps({k: v for k, v in rec.items() if k != "scene_names"}))
    print("C1 RUN V02 DONE")


if __name__ == "__main__":
    main()
